---
title: Word een AWS Certified Azure expert
date: '2019-07-06T09:27:17.000+00:00'
bg_image: images/backgrounds/page-title.jpg
description: ''
image: "/images/microsoft_certified_badges_1110_500.png"
category: Data
teacher: Maarten
duration: ''
apply_url: "/contact"

---
Lora Lora