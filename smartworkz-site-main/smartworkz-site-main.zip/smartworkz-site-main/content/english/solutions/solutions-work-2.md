---
title: Word een AWS Certified Analytics expert
image: images/solutions/hero.jpg
icon: ti-cup
weight: 2
focus: workshop

---
Onze Microsoft gecertificeerde trainers nemen je mee in de AWS wereld van AI en ML. 